/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* Server
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(['./t2kapi.logger'],
function(Logger) {

	var _server_state = 'ONLINE';
	var _server_domain = window.location.protocol + '//' + document.domain + '/lms/';

	var _config = {
		serverAjaxRetries: 3,
		serverAjaxRetryDelay: 250
	};

	var _change_state_listeners = [];

	var createResource = function(url, data) {
		var val,key,rx;
		if (data) {
			for (key in data) {
				val = data[key];
				rx = new RegExp(":"+key,'g');
				url = url.replace(rx,val);
			}
		}
		return url;
	};

	var isServerError = function(jqXHR) {
		var serverErrObj;
		if (jqXHR && jqXHR.responseText) {
			try {
				serverErrObj = JSON.parse(jqXHR.responseText);
				if (serverErrObj && serverErrObj.errorCode) {
					return true;
				}
			} catch (ex) {
				return false;
			}
		}
		return false;
	};

	var isServerResponse = function(jqXHR) {
		var header = jqXHR.getResponseHeader('T2kSignature');
		return header || isServerError(jqXHR);
	};

	var updateServerState = function(newState) {
		if (_server_state !== newState) {
			Logger.d('server', 'server has a new state: $$', newState);
			for (var i = 0; i < _change_state_listeners.length; i++) {
				_change_state_listeners[i].apply(this, [(newState === 'ONLINE')]);
			}
			_server_state = newState;
		}
	};

	return {

		config: function(params) {
			for (var key in params) {
				_config[key] = params[key];
			}
		},

		get: function(url, params, options) {
			var options = options || {},
				success = options.success || function(){},
				context = options.context || this,
				error = options.error || function(){},
				offline = options.offline || function(){},
				crossDomain = options.crossDomain || false,
				xhrFields = options.xhrFields || {},
				data = options.data || null;

			url = createResource(url, params);

			Logger.d('server', 'fetching data from server for url', url);

			$.ajax({
				url: _server_domain + url,
				dataType: 'json',
				data: data,
				retriesCounter: 1,
				crossDomain: crossDomain,
				xhrFields: xhrFields,
				success: function(data) {
					updateServerState('ONLINE');
					Logger.d('server', 'data from server is fetched successfully for url $$, data $$', url, data);
					success.apply(context, [data]);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					if (!isServerResponse(jqXHR)) {
						if (this.retriesCounter === _config.serverAjaxRetries) {
							Logger.d('server', 'server is not reachable, going to offline mode, cant fetch url: $$', url);
							updateServerState('OFFLINE');
							offline.apply(context, []);
						} else {
							this.retriesCounter++;
							var ajaxContext = this;
							setTimeout(function(){
								$.ajax(ajaxContext);
							},_config.serverAjaxRetryDelay);
						}
					} else {
						Logger.e('server', 'server error for url $$', url);
						error(jqXHR, textStatus, errorThrown);
					}
				}
			});
		},

		saveInChunks: function(url, params, options) {
			var options = options || {},
				success = options.success || function(){},
				context = options.context || this,
				offline = options.offline || function(){},
				error = options.error || function(){},
				chunk_success = options.chunk_success || function(){},
				dataArray = params.data,
				itemsInChunk = 10;

			var runChunkSave = function(data, cIndex) {
				this.save(url, {data: data}, {
					success: function(res) {
						Logger.d('server', 'chunk #$$ is sent successfuly', cIndex);
						chunk_success.apply(context, [(cIndex * itemsInChunk), data.length, res]);
					},
					error: error,
					offline: error
				});
			};

			if (dataArray.length) {
				var chunkIndex = 0;
				while (dataArray.length) {
					runChunkSave.apply(this, [dataArray.splice(0, itemsInChunk), chunkIndex++]);
				}
			} else {
				success.apply(context, [[]]);
			}
		},

		put: function(url, params, options) {
			options.type = 'put';
			this.save(url, params, options);
		},

		post: function(url, params, options) {
			options.type = 'post';
			this.save(url, params, options);
		},

		save: function(url, params, options) {
			var options = options || {},
				success = options.success || function(){},
				context = options.context || this,
				offline = options.offline || function(){},
				error = options.error || function(){};
			url = createResource(url, params);
			Logger.d('server', 'post data to server for url $$', url);
			$.ajax({
				url: _server_domain + url ,
				dataType: 'json',
				type: options.type || 'put',
				contentType: "application/json",
				data: JSON.stringify(params.data),
				retriesCounter: 1,
				success: function(data){
					Logger.d('server', 'successfully posting data to server for url $$', url);
					updateServerState('ONLINE');
					success.apply(context, [data]);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					if (!isServerResponse(jqXHR)) {
						if (this.retriesCounter === _config.serverAjaxRetries) {
							Logger.d('server', 'server is not reachable, going to offline mode, cant save url: $$', url);
							updateServerState('OFFLINE');
							offline.apply(context, []);
						} else {
							this.retriesCounter++;
							var ajaxContext = this;
							setTimeout(function(){
								$.ajax(ajaxContext);
							},_config.serverAjaxRetryDelay);
						}
					} else {
						Logger.d('server', 'server error for url $$', url);
						error(jqXHR, textStatus, errorThrown);
					}
				}
			});
		},

		isOnline: function(callback) {
			$.ajax({
				url: _server_domain + 'ext/ping',
				type: 'head',
				timeout: 5000,
				retriesCounter: 1,
				success: function() {
					callback(true);
				},
				error: function(jqXHR) {
					if (this.retriesCounter === _config.serverAjaxRetries) {
						callback(false);
					} else {
						this.retriesCounter++;
						$.ajax(this);
					}
				}
			});
		},

		onChangeState: function(listener) {
			_change_state_listeners.push(listener);
		}
	};
});