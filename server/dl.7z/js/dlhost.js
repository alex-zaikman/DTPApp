define( [ "jquery", "player" ], function( $, player ) {
	
	function DLHost(){
		
		this.player = null ;
		
	//	this.playerPath = getPlayerPath() ;
		
		//this.initPlayer() ;
		
	}
		
	DLHost.prototype = {
		
		initAndPlay: function(initJSON, playJSON) {
			this.initPlayer(initJSON, function() {
				this.playSequence( playJSON ) ;
			} ) ;
		},
		
		initPlayer: function( data, callback ) {
						
			this.player = new player( this, "#player") ;
			
			this.player.api( {
				action: 'init',
				data: data,
				success: callback,
				error: function() {
					alert('player init error') ;
				}
			} ) ;
		},
			
		api: function( config ) {
			
			
			console.info( "API call from DL --> %s --> %O", config.action, config ) ;
//			try {
//				console.info( JSON.stringify(config, null, '\t') )
//			} catch (e) {
//				console.info( config ) ;
//			}
			
			var callSuccess = true ;
			
			if( this.apiFunctions[config.action] ) {
				callSuccess = false ;
				this.apiFunctions[config.action].call(this, config);
			} else {
				console.info( "----> no handler for API action --> ", config.action ) ;
			}

			if( callSuccess && config.success ) {
				config.success() ;
       		}
        },

        apiFunctions: {
            saveState: function (config) {
        		config.success() ;
            }
        },
		
		onPlayerInitiated: function() {
			
			this.playSequence() ;
			
		},

		playSequence: function( data ) {
			
			var seqData = data; //this.mockSequenceData() ;
			var seqId = seqData[seqData.constructor.keys(seqData)[0]].id ;
			
			var playConfig = {
					
				data: seqData,
				id: seqId,
				state: null,
				saveState: true
					
			} ;
			
			var thi$ = this ;
			
			this.player.api( {
				action: 'playSequence',
				data: playConfig,
				success: function( config ){ thi$.onSequencePlayed( config ) ; },
				error: function(){ alert( "sequnce error" ) ; }
			} ) ;
		},
		
		onSequencePlayed: function( config ) {
			
		},

		onSequenceDataError: function() {
			alert("seq data error")
		},
		
		onApiCall: function( action ) {
			
			var thi$ = this ;
			
			if( this.player ) {
				
				this.player.api( {
					action: action,
					data: null,
					success: function(){
						
						console.info( action + " --> success callback!" ) ;
						
						if( action == 'terminate' ) {
							thi$.player = null ;
						}
//						alert( action + " success" ) ;
					},
					error: function(){
						console.error( action + " --> error callback!" ) ;
//						alert( action + " error" ) ;
					}
				} ) ;
				
			} else {
				alert( "Play sequence 1st, then use api..." ) ;
			}
			
		},
		
		assetsPathRouter: function () {
			
			var thi$ = this ;
			
			var router = function( relative ) {
				// set default
				var baseServerPath = "" ;
				
				var prefix = baseServerPath + "/dl-old/assets/" ;
				
				if( relative.indexOf( "applets" ) != -1 ) {
					prefix = baseServerPath + "/applets-sandbox/" ;
				}
				
				if( thi$.overrideMediaPath ) {
					var path = thi$.overrideMediaPath ;
					if( thi$.overrideMediaPath.indexOf( "./" ) == 0 ) {
						path = thi$.overrideMediaPath.replace( "./", "" ) ;
					} else if( thi$.overrideMediaPath.indexOf( "/" ) == 0 ) {
						path = thi$.overrideMediaPath.replace( "/", "" ) ;
					}
					prefix =  baseServerPath + "../" + path ;
				}
				
				return prefix + relative ;
			}
			
			return router ;
		},
		

		
		mockInitData: function() {
			// replace mock here - change sizes
			return {
				width: 1024,
				height: 600,
				scale: 1,
				basePaths: {
					player: this.playerPath,
					media: this.assetsPathRouter() // also string prefix path is possible
				},
				
				complay:true,
				localeName:"en_US",
				apiVersion: '1.0',
				loId: 'inst_s',
				isLoggingEnabled: true,
				userInfo : {
					role: 'student'
				} 
			} ;
		},

		mockSequenceData: function() {
			// replace mock here
			return  {
				"d3865588-c7f5-4fa8-8fb8-44aff8120315":{
					"type": "sequence",
					"parent": "f5231923-0adf-480f-aa9c-3fc329fee1a6",
					"children": [
						"7b216e4c-e645-4856-9d98-090feab49d7b"
					],
					"data": {
						"title": "New sequence 1",
						"type": "simple",
						"exposure": "all_exposed",
						"isThumbnailUpdated": true,
						"selectedStandards": [],
						"thumbnail": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAJfklEQ�gsrwEJSCA3BAxWblQ5VAISMFheAxKQQG4IGKzcqHKoBCTwL6XqNMQWwq3NAAAAAElFTkSuQmCC"
					},
					"id": "d3865588-c7f5-4fa8-8fb8-44aff8120315",
					"isCourse": false,
					"convertedData": "<sequence type=\"simple\" id=\"d3865588-c7f5-4fa8-8fb8-44aff8120315\">\n\t\n\n    \n<task exposureid=\"1\" type=\"questionOnly\" id=\"7b216e4c-e645-4856-9d98-090feab49d7b\">\n    \n    <!-- in cloze task -->\n    \n\n    <!-- in mtq task -->\n    \n<question id=\"4ade1068-888d-4c07-b19d-6728e6aeeba1\" auto_tag=\"auto_tag\">\n\t\n\n<textviewer id=\"6d152068-4b11-4913-968d-f2dabbd4d360\" style=\"texteditor\">\n    <p><span class=\"normal\">tgfhjvgfhkgfhjk<br></span></p>\n\n\n    \n</textviewer>\n\n\n</question>\n<progress id=\"8d801ef0-1d6e-4651-a671-db33f54405cc\">\n\t<attempts></attempts>\n\n\t<checkable>true</checkable>\n\n    \n\n<instruction id=\"0878f70b-5ebd-4d4c-8383-04fc3ab22db9\">\n    \n\n<textviewer id=\"9728f94f-1903-43ff-ae15-a35c63f5b754\" style=\"\">\n    <p>Click to edit the instruction.</p>\n\n\n    \n</textviewer>\n\n\n</instruction>\n\n</progress>\n\n</task><task exposureid=\"1\" type=\"questionOnly\" id=\"7b216e4c-e645-4856-9d98-090feab49d7b\">\n    \n    <!-- in cloze task -->\n    \n\n    <!-- in mtq task -->\n    \n<question id=\"4ade1068-888d-4c07-b19d-6728e6aeeba1\" auto_tag=\"auto_tag\">\n\t\n\n<textviewer id=\"6d152068-4b11-4913-968d-f2dabbd4d360\" style=\"texteditor\">\n    <p><span class=\"normal\">tgfhjvgfhkgfhjk<br></span></p>\n\n\n    \n</textviewer>\n\n\n</question>\n<progress id=\"8d801ef0-1d6e-4651-a671-db33f54405cc\">\n\t<attempts></attempts>\n\n\t<checkable>true</checkable>\n\n    \n\n<instruction id=\"0878f70b-5ebd-4d4c-8383-04fc3ab22db9\">\n    \n\n<textviewer id=\"9728f94f-1903-43ff-ae15-a35c63f5b754\" style=\"\">\n    <p>Click to edit the instruction.</p>\n\n\n    \n</textviewer>\n\n\n</instruction>\n\n</progress>\n\n</task><task exposureid=\"1\" type=\"questionOnly\" id=\"7b216e4c-e645-4856-9d98-090feab49d7b\">\n    \n    <!-- in cloze task -->\n    \n\n    <!-- in mtq task -->\n    \n<question id=\"4ade1068-888d-4c07-b19d-6728e6aeeba1\" auto_tag=\"auto_tag\">\n\t\n\n<textviewer id=\"6d152068-4b11-4913-968d-f2dabbd4d360\" style=\"texteditor\">\n    <p><span class=\"normal\">tgfhjvgfhkgfhjk<br></span></p>\n\n\n    \n</textviewer>\n\n\n</question>\n<progress id=\"8d801ef0-1d6e-4651-a671-db33f54405cc\">\n\t<attempts></attempts>\n\n\t<checkable>true</checkable>\n\n    \n\n<instruction id=\"0878f70b-5ebd-4d4c-8383-04fc3ab22db9\">\n    \n\n<textviewer id=\"9728f94f-1903-43ff-ae15-a35c63f5b754\" style=\"\">\n    <p>Click to edit the instruction.</p>\n\n\n    \n</textviewer>\n\n\n</instruction>\n\n</progress>\n\n</task><task exposureid=\"1\" type=\"questionOnly\" id=\"7b216e4c-e645-4856-9d98-090feab49d7b\">\n    \n    <!-- in cloze task -->\n    \n\n    <!-- in mtq task -->\n    \n<question id=\"4ade1068-888d-4c07-b19d-6728e6aeeba1\" auto_tag=\"auto_tag\">\n\t\n\n<textviewer id=\"6d152068-4b11-4913-968d-f2dabbd4d360\" style=\"texteditor\">\n    <p><span class=\"normal\">tgfhjvgfhkgfhjk<br></span></p>\n\n\n    \n</textviewer>\n\n\n</question>\n<progress id=\"8d801ef0-1d6e-4651-a671-db33f54405cc\">\n\t<attempts></attempts>\n\n\t<checkable>true</checkable>\n\n    \n\n<instruction id=\"0878f70b-5ebd-4d4c-8383-04fc3ab22db9\">\n    \n\n<textviewer id=\"9728f94f-1903-43ff-ae15-a35c63f5b754\" style=\"\">\n    <p>Click to edit the instruction.</p>\n\n\n    \n</textviewer>\n\n\n</instruction>\n\n</progress>\n\n</task><task exposureid=\"1\" type=\"questionOnly\" id=\"7b216e4c-e645-4856-9d98-090feab49d7b\">\n    \n    <!-- in cloze task -->\n    \n\n    <!-- in mtq task -->\n    \n<question id=\"4ade1068-888d-4c07-b19d-6728e6aeeba1\" auto_tag=\"auto_tag\">\n\t\n\n<textviewer id=\"6d152068-4b11-4913-968d-f2dabbd4d360\" style=\"texteditor\">\n    <p><span class=\"normal\">tgfhjvgfhkgfhjk<br></span></p>\n\n\n    \n</textviewer>\n\n\n</question>\n<progress id=\"8d801ef0-1d6e-4651-a671-db33f54405cc\">\n\t<attempts></attempts>\n\n\t<checkable>true</checkable>\n\n    \n\n<instruction id=\"0878f70b-5ebd-4d4c-8383-04fc3ab22db9\">\n    \n\n<textviewer id=\"9728f94f-1903-43ff-ae15-a35c63f5b754\" style=\"\">\n    <p>Click to edit the instruction.</p>\n\n\n    \n</textviewer>\n\n\n</instruction>\n\n</progress>\n\n</task>\n</sequence>"
				}
			} ;
		}
		
	};
	
	function getBaseURL() {
		var baseURL ;
		
		if( window.location.origin ) {
			baseURL = window.location.origin ;
		} else { // IE
			baseURL = window.location.protocol + "//" + window.location.host ;
		}
		
		baseURL += window.location.pathname ;
		
		return baseURL ;
	}
	
	function getPlayerPath() {
		var playerPath = getBaseURL().split( '/' ) ;
		playerPath.pop() ;
		playerPath = playerPath.join( '/' ) + "/player" ;
//		playerPath = playerPath.join( '/' ) + "/min" ;
		return playerPath ;
	}
	
	return DLHost ;

});

