require.config( {

	baseUrl: '',

	paths: {
		
		/* libs */
		jquery: 'js/libs/jquery/jquery',
		
		/* dl simulator host */
		dlhost: 'js/dlhost',

		/* dl player */
		player: 'player'
		
	}

} ) ;

require( [ "dlhost" ], function( dlhost ) {
	
	window.dlhost = new dlhost() ;
	
});
