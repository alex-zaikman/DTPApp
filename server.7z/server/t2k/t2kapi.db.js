/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* DB Manager
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(['./t2kapi.logger'],
function(Logger) {

	var _db_handler = null;
	var DB_SIZE = 10 * 1024 * 1024;

	var select = function(query, callback, error) {
		error = error || function(){};
		Logger.d('db', 'start executing query: $$', query);
		_db_handler.transaction(function(tx) {
			tx.executeSql(query, [], function(tx, results) {
				var items = [];
				for (var i = 0; i < results.rows.length; i++) {
					items[i] = {};
					for (var key in results.rows.item(i)) {
						items[i][key] = decodeData(results.rows.item(i)[key]);
					}
				}
				callback(items);
			});
		}, function(err){
			Logger.d('db', 'query error $$, $$',query, err);
			callback.apply(this, []);
		});
	};

	var update = function(createQuery, insertQuery, callback, error) {
		var error = error || function(){};
		Logger.d('db', 'open new transaction to update data');
		_db_handler.transaction(function(tx) {
			Logger.d('db', 'run query: ' + createQuery);
			tx.executeSql(createQuery, [], function(){});
			Logger.d('db', 'run query: ' + insertQuery);
			tx.executeSql(insertQuery, [], function(){
				callback();
			});
		}, function(err) {
			Logger.e('db', 'update process error: $$', err);
			error(err);
		});
	};

	var getTableFields = function(params, withPrimaryKey) {
		var tableFields = [];
		var primaryKeyArray = [];
		for (var column in params) {
			if ((column === 'dirty') || (column === "modified")) {
				continue;
			}
			tableFields.push(column);
			if (column !== 'data') {
				primaryKeyArray.push(column);
			}
		}
		tableFields.push('dirty');
		tableFields.push('modified');
		if (withPrimaryKey) {
			tableFields.push('PRIMARY KEY ('+primaryKeyArray.join(',')+')');
		}
		return tableFields;
	};

	var getTableValues = function(params, dirty) {
		var values = [];
		for (var column in params) {
			var val = params[column];
			if ((column === 'dirty') || (column === "modified")) {
				continue;
			}
			switch (typeof(val)) {
				case 'number':
					values.push(val);
				break;
				case 'object':
					values.push('"'+encodeData(val)+'"')
				break;
				default:
					values.push('"'+val+'"');
				break;
			}
		}
		values.push((dirty) ? 1 : 0);
		values.push('"' + new Date() + '"');
		return values;
	};

	var getTableSearch = function(params) {
		var conditions = [];
		for (var column in params) {
			if (column === 'data') {
				continue;
			}
			var val = params[column];
			switch (typeof(val)) {
				case 'number':
					val = val;
				break;
				default:
					val = '"'+val+'"';
				break;
			}
			conditions.push(column + ' = ' + val);
		}
		return conditions;
	};

	var encodeData = function(data) {
		var dataStr;
		if (typeof(data) === 'undefined') {
			return data;
		}
		try {
			dataStr = JSON.stringify(data);
		} catch (e) {
			dataStr = data;
		} finally {
			return dataStr.replace(/"/g, '&quot;');
		}
    };

    var decodeData = function(data) {
    	if (typeof(data) === 'undefined') {
    		return data;
    	}
        var dataObj;
    	try {
    		data = data.replace(/&quot;/g, '"');
    		dataObj = JSON.parse(data);
    	} catch (e) {
    		dataObj = data;
    	} finally {
    		return dataObj;
    	}
    };

	return {

		init: function() {
			_db_handler = openDatabase('t2kapi-db', '1.0', 't2k api db', DB_SIZE);
		},

		save: function(table, params, options) {
			var options = options || {},
				success = options.success || function(){},
				error = options.error || function(){},
				context = options.context || this,
				dirty = options.dirty,
				createString = 'CREATE TABLE IF NOT EXISTS ' + table + ' ('+getTableFields(params, true).join(',') +')',
				insertString = 'INSERT OR REPLACE INTO ' + table + '(' + getTableFields(params, false).join(',') + ') VALUES ('+getTableValues(params, dirty).join(',')+')';

			update(createString, insertString, success, error);
		},

		get: function(table, params, options) {
			var options = options || {},
				success = options.success || function(){},
				error = options.error || function(){},
				context = options.context || this,
				conditions = getTableSearch(params),
				selectString = (conditions.length) ? 'SELECT * FROM ' + table + ' WHERE ' + conditions.join(' and ') : 'SELECT * FROM ' + table;
			select(selectString, function(items){
				success.apply(context, [items]);
			}, function(e){
				Logger.e('db', 'failed to get params $$ with error $$',params, e);
				error.apply(context, [e]);
			});
		},

		clear: function(table, params) {
			var conditions = getTableSearch(params),
				selectString = (conditions.length) ? 'DELETE FROM ' + table + ' WHERE ' + conditions.join(' and ') : 'DELETE FROM ' + table;
			Logger.d('db', 'clearing table: $$ where: $$', table, params);
			select(selectString, function(){
				Logger.d('db', 'clear $$ where $$ successfull', table, params);
			},function(){
				Logger.e('db', 'clear $$ where $$ failed', table, params);
			});
		},

		getHandler: function() {
			return _db_handler;
		}
	};
	return DB;
});
